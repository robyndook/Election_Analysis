# @TODO: Your code here
dog_info = {
    "name": "Loe",
    "age": 1,
    "hobbies":["walking", "catch", "barking"],
    "wakeup":{"Mon":"7am", "Tue":{"Mon":"7am", "Tue":"6am"}}

}

dog_info["wakeup"]["Tue"]["Mon"]

print(f'My dog\'s name is {dog_info["name"]}')
print(f"""My dog's name is {dog_info["name"]}""")
info = f"""
My dog's name is {dog_info["name"]}
"""

print(info)