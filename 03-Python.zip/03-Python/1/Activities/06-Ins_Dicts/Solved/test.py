names = [
    "Khaled",
    "Leila",
    "Tai",
    "Amar"
]
addresses = [
    "Boston",
    "Cal",
    "Cal",
    "Cal"
]

class_info = [
    {
        "name": "Khaled",
        "address": "Boston"
    },
        {
        "name": "Leila",
        "address": "California",
        "books": ["Harry"]
    }

]

class_info[1]


# class_info["address"]