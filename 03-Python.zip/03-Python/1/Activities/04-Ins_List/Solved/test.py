my_inf = ["Khaled", 4000, True]

my_inf[0]
my_inf[1]
my_inf.append("15")
my_inf[3] = 15
my_inf.index(15)
my_inf.remove("Khaled")
my_inf.pop(0)

# my_inf = [
#     0: "Khaled",
#     1: 4000,
#     2: True
#     ]