# Modules
import os
import csv

# Prompt user for video lookup
# video = input("What show or movie are you looking for? ")
video = "Scream"

# Set path for file
from pathlib import Path

file_path = Path("../Resources/netflix_ratings.csv")
# Bonus - Step 1
# ------------------------------------------
# Set a variable to false to check if we found the video
movie_details = []
with open(file_path, "r") as netflix:
    csv_data = csv.reader(netflix, delimiter=",")
    header = next(csv_data)
    print(header)
    for raw in csv_data:
        if raw[0]==video:
            movie_details = raw

print(movie_details)
file_path = Path("../Resources/movie_details.csv")
with open(file_path, "w") as netflix:
    writer = csv.writer(netflix)
    writer.writerow(movie_details)
# Open the CSV


    # Loop through looking for the video
    


            # Bonus - Step 2: Set the variable created in Step 1 to confirm we have found the video
            

            # Bonus - Step 3: Stop at first results to avoid duplicates
            

    # Bonus - Step 4:  If the video is never found, alert the user
    
        # print("Sorry about this, we don't seem to have what you are looking for!")
