## The conditional puzzle

### Instructions

* Look through the examples and figure out what line will print.

* Do not run the code at first, see if you can follow the thought process and guess.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.