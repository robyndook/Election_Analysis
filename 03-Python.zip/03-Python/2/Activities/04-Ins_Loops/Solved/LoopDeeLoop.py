# Loop through a range of numbers (0 through 4)
list(range(0, 5, 1))

for x in range(5):
    print(x)

print("-----------------------------------------")

# Loop through a range of numbers (2 through 6 - yes 6! Up to, but not including, 7)
for x in range(2, 7):
    print(x)

print("----------------------------------------")

# Iterate through letters in a string
word = "Peace"
for x in word:
    print(x)

print("----------------------------------------")

# Iterate through a list
zoo = ["cow", "dog", "bee", "zebra"]
for animal in zoo:
    print(animal)

a = {"a":"b", "c":"d"}
for key, val in a.items():
    print(key, val)

print("----------------------------------------")

# Loop while a condition is being met
run_this = "y"

while run_this == "y":
    print("Hi!")
    run_this = input("To run again. Enter 'y'")

