# Module 3 | Assignment - PyPoll

Use the power of Python to automate the vote-counting process for an election.
